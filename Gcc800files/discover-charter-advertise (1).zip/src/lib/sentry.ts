// Sentry is disabled - no DSN configured
export const initSentry = () => {
  // Sentry initialization disabled
  console.log('Sentry monitoring is disabled');
};
