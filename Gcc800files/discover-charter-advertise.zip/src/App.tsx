import { Suspense, lazy } from "react";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { ThemeProvider } from "@/components/theme-provider";
import DashboardSkeleton from "@/components/skeletons/DashboardSkeleton";
import { ErrorBoundary } from "@/components/ErrorBoundary";
import PerformanceMonitor from "@/components/PerformanceMonitor";

// Lazy load route components for code splitting
const Index = lazy(() => import("./pages/Index"));
const NotFound = lazy(() => import("./pages/NotFound"));
const PaymentSuccess = lazy(() => import("./pages/PaymentSuccess"));
const CaptainDashboard = lazy(() => import("./components/CaptainDashboard"));
const CustomerDashboard = lazy(() => import("./components/CustomerDashboard"));


const App = () => (
  <ThemeProvider defaultTheme="light">
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <PerformanceMonitor />
      <BrowserRouter>
        <Suspense fallback={<DashboardSkeleton />}>
          <Routes>
            <Route path="/" element={
              <ErrorBoundary><Index /></ErrorBoundary>
            } />
            <Route path="/captain-dashboard" element={
              <ErrorBoundary><CaptainDashboard /></ErrorBoundary>
            } />
            <Route path="/my-bookings" element={
              <ErrorBoundary><CustomerDashboard /></ErrorBoundary>
            } />
            <Route path="/payment-success" element={
              <ErrorBoundary><PaymentSuccess /></ErrorBoundary>
            } />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </Suspense>
      </BrowserRouter>
    </TooltipProvider>
  </ThemeProvider>
);

export default App;

