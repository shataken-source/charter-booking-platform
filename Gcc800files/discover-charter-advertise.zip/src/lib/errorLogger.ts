import * as Sentry from '@sentry/react';

export interface ErrorContext {
  userId?: string;
  userEmail?: string;
  component?: string;
  action?: string;
  [key: string]: any;
}

export const logError = (error: Error, context?: ErrorContext) => {
  console.error('Error logged:', error, context);
  
  if (import.meta.env.PROD) {
    Sentry.captureException(error, {
      contexts: {
        custom: context,
      },
      tags: {
        component: context?.component,
        action: context?.action,
      },
      user: context?.userId ? {
        id: context.userId,
        email: context.userEmail,
      } : undefined,
    });
  }
};

export const logMessage = (message: string, level: 'info' | 'warning' | 'error' = 'info', context?: ErrorContext) => {
  console[level === 'error' ? 'error' : level === 'warning' ? 'warn' : 'log'](message, context);
  
  if (import.meta.env.PROD) {
    Sentry.captureMessage(message, {
      level,
      contexts: { custom: context },
    });
  }
};
