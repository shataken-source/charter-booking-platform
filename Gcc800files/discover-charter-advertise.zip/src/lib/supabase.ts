import { createClient } from '@supabase/supabase-js';


// Initialize database client
const supabaseUrl = 'https://xzdzmeaxbjvntuqeommq.databasepad.com';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImYzYzVhMDk4LTA5NWQtNDA2Ni05YjU4LTJiYzBhYTc2ODliNCJ9.eyJwcm9qZWN0SWQiOiJ4emR6bWVheGJqdm50dXFlb21tcSIsInJvbGUiOiJhbm9uIiwiaWF0IjoxNzYzMjE4OTgyLCJleHAiOjIwNzg1Nzg5ODIsImlzcyI6ImZhbW91cy5kYXRhYmFzZXBhZCIsImF1ZCI6ImZhbW91cy5jbGllbnRzIn0.wCpqb96UA1bx0cpPX4qC4JS4FPxkfTjzDuVSlNxPWVE';
const supabase = createClient(supabaseUrl, supabaseKey);


export { supabase };