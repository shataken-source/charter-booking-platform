import { onCLS, onFID, onFCP, onLCP, onTTFB, Metric } from 'web-vitals';
import * as Sentry from '@sentry/react';

// Web Vitals thresholds
const THRESHOLDS = {
  CLS: 0.1,
  FID: 100,
  FCP: 1800,
  LCP: 2500,
  TTFB: 800,
};

// Send metrics to analytics and Sentry
function sendToAnalytics(metric: Metric) {
  const { name, value, rating } = metric;
  
  console.log(`[Performance] ${name}:`, {
    value: Math.round(value),
    rating,
  });

  // Send to Sentry for monitoring
  Sentry.addBreadcrumb({
    category: 'performance',
    message: `${name}: ${Math.round(value)}ms`,
    level: rating === 'good' ? 'info' : rating === 'needs-improvement' ? 'warning' : 'error',
    data: { metric: name, value, rating },
  });

  // Track poor performance
  if (rating === 'poor') {
    Sentry.captureMessage(`Poor ${name} performance: ${Math.round(value)}`, 'warning');
  }
}

// Initialize Web Vitals monitoring
export function initPerformanceMonitoring() {
  onCLS(sendToAnalytics);
  onFID(sendToAnalytics);
  onFCP(sendToAnalytics);
  onLCP(sendToAnalytics);
  onTTFB(sendToAnalytics);
}

// Performance mark utility
export function markPerformance(name: string) {
  if ('performance' in window) {
    performance.mark(name);
  }
}

// Measure performance between marks
export function measurePerformance(name: string, startMark: string, endMark: string) {
  if ('performance' in window) {
    try {
      performance.measure(name, startMark, endMark);
      const measure = performance.getEntriesByName(name)[0];
      console.log(`[Performance] ${name}: ${Math.round(measure.duration)}ms`);
      return measure.duration;
    } catch (e) {
      console.warn('Performance measurement failed:', e);
    }
  }
  return 0;
}
