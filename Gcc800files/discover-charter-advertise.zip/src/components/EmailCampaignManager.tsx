import React, { useState } from 'react';
import { supabase } from '@/lib/supabase';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';

const EmailCampaignManager: React.FC = () => {
  const [campaignType, setCampaignType] = useState<'email' | 'sms'>('email');
  const [recipients, setRecipients] = useState('');
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  const templates = {
    welcome: {
      subject: 'Welcome to WhereToVacation!',
      message: 'Thank you for subscribing! We\'ll keep you updated on the best vacation deals and destinations.'
    },
    promotion: {
      subject: 'Special Offer: 20% Off Your Next Booking',
      message: 'Book now and save 20% on any vacation package this month. Use code SAVE20 at checkout.'
    },
    reminder: {
      subject: 'Don\'t Miss Out on Summer Vacations',
      message: 'Summer is here! Book your dream vacation today before spots fill up.'
    }
  };


  const handleSend = async () => {
    setLoading(true);
    setResult(null);

    try {
      const recipientList = recipients.split(',').map(r => r.trim()).filter(r => r);
      
      if (recipientList.length === 0) {
        throw new Error('Please enter at least one recipient');
      }

      const { data, error } = await supabase.functions.invoke('brevo-campaign', {
        body: {
          action: campaignType === 'email' ? 'send-email' : 'send-sms',
          recipients: recipientList,
          subject: campaignType === 'email' ? subject : undefined,
          htmlContent: campaignType === 'email' ? `<html><body>${message}</body></html>` : undefined,
          textContent: message,
          senderName: 'WhereToVacation',
          senderEmail: 'info@wheretovacation.com'

        }
      });

      if (error) throw error;

      setResult({ type: 'success', message: `${campaignType === 'email' ? 'Email' : 'SMS'} sent to ${recipientList.length} recipient(s)!` });
      setRecipients('');
      setSubject('');
      setMessage('');
    } catch (error: any) {
      setResult({ type: 'error', message: error.message });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-6 flex gap-3">
        <Button 
          variant="outline" 
          onClick={() => window.location.hash = '#email-template'}
        >
          View Captain Email Template
        </Button>
        <Button 
          variant="outline" 
          onClick={() => window.location.hash = '#advertiser-template'}
        >
          View Advertiser Email Template
        </Button>
      </div>

      
      <Card>
        <CardHeader>
          <CardTitle>Email & SMS Campaign Manager</CardTitle>
        </CardHeader>

        <CardContent>
          <Tabs value={campaignType} onValueChange={(v) => setCampaignType(v as 'email' | 'sms')}>
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="email">Email Campaign</TabsTrigger>
              <TabsTrigger value="sms">SMS Campaign</TabsTrigger>
            </TabsList>

            <TabsContent value="email" className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">Recipients (comma-separated emails)</label>
                <Input
                  placeholder="customer1@email.com, customer2@email.com"
                  value={recipients}
                  onChange={(e) => setRecipients(e.target.value)}
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Subject</label>
                <Input
                  placeholder="Email subject"
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Message</label>
                <Textarea
                  placeholder="Email message"
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  rows={6}
                />
              </div>

              <div className="flex gap-2">
                {Object.entries(templates).map(([key, template]) => (
                  <Button
                    key={key}
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      setSubject(template.subject);
                      setMessage(template.message);
                    }}
                  >
                    {key.charAt(0).toUpperCase() + key.slice(1)}
                  </Button>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="sms" className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">Phone Number (with country code)</label>
                <Input
                  placeholder="+1234567890"
                  value={recipients}
                  onChange={(e) => setRecipients(e.target.value)}
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Message (160 chars max)</label>
                <Textarea
                  placeholder="SMS message"
                  value={message}
                  onChange={(e) => setMessage(e.target.value.slice(0, 160))}
                  rows={4}
                />
                <p className="text-sm text-gray-500 mt-1">{message.length}/160</p>
              </div>
            </TabsContent>
          </Tabs>

          {result && (
            <Alert className={result.type === 'success' ? 'bg-green-50' : 'bg-red-50'}>
              <AlertDescription>{result.message}</AlertDescription>
            </Alert>
          )}

          <Button onClick={handleSend} disabled={loading} className="w-full mt-4">
            {loading ? 'Sending...' : `Send ${campaignType === 'email' ? 'Email' : 'SMS'}`}
          </Button>
        </CardContent>
      </Card>
    </div>
  );
};

export default EmailCampaignManager;