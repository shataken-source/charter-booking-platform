/**
 * Footer Component
 * 
 * Displays the site footer with company information, navigation links,
 * popular activities, and contact information.
 * Features a dark gradient background with improved text contrast.
 */
export default function Footer() {
  return (
    // Main footer container with gradient background from dark gray to purple
    <footer className="bg-gradient-to-br from-gray-900 via-purple-900/20 to-gray-900 text-white py-16">
      <div className="container mx-auto px-4">
        {/* Four-column grid layout for footer sections */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          
          {/* Column 1: Logo and Company Description */}
          <div>
            <div className="flex items-center gap-3 mb-4">
              {/* Company logo */}
              <img 
                src="https://d64gsuwffb70l.cloudfront.net/6918960e54362d714f32b6fc_1763250968269_90e31cef.webp" 
                alt="Where to Vacation Logo" 
                className="w-12 h-12 object-contain"
              />
              {/* Company name with gradient text effect */}
              <h3 className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-violet-400">WhereToVacation</h3>
            </div>
            {/* Company tagline - lighter gray for better readability */}
            <p className="text-gray-200 leading-relaxed">
              Your premier destination for finding the perfect vacation, destination, and travel experiences worldwide.
            </p>
          </div>

          {/* Column 2: Quick Navigation Links */}
          <div>
            <h4 className="font-bold mb-4 text-purple-300">Quick Links</h4>
            <ul className="space-y-3">
              {/* Navigation links with hover effects */}
              <li><a href="#search" className="text-gray-200 hover:text-purple-300 transition-colors duration-200">Search Destinations</a></li>
              <li><a href="#advertise" className="text-gray-200 hover:text-purple-300 transition-colors duration-200">Advertise</a></li>
              <li><a href="#about" className="text-gray-200 hover:text-purple-300 transition-colors duration-200">About Us</a></li>
            </ul>
          </div>

          {/* Column 3: Popular Activities Links */}
          <div>
            <h4 className="font-bold mb-4 text-purple-300">Popular Activities</h4>
            <ul className="space-y-3">
              {/* Activity category links with hover effects */}
              <li><a href="#activity/diving" className="text-gray-200 hover:text-purple-300 transition-colors duration-200">Scuba Diving</a></li>
              <li><a href="#activity/hiking" className="text-gray-200 hover:text-purple-300 transition-colors duration-200">Hiking</a></li>
              <li><a href="#activity/beach" className="text-gray-200 hover:text-purple-300 transition-colors duration-200">Beach Activities</a></li>
              <li><a href="#activity/culture" className="text-gray-200 hover:text-purple-300 transition-colors duration-200">Cultural Tours</a></li>
            </ul>
          </div>

          {/* Column 4: Contact Information and Legal Links */}
          <div>
            <h4 className="font-bold mb-4 text-purple-300">Contact</h4>
            <ul className="space-y-3 text-gray-200">
              {/* Contact details */}
              <li>Email: info@wheretovacation.com</li>
              <li>Phone: (555) 123-4567</li>
              {/* Legal links */}
              <li className="pt-4">
                <a href="#terms" className="hover:text-purple-300 transition-colors duration-200">Terms of Service</a>
              </li>
              <li>
                <a href="#privacy" className="hover:text-purple-300 transition-colors duration-200">Privacy Policy</a>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom copyright section with border separator */}
        <div className="border-t border-gray-700/50 mt-12 pt-8 text-center text-gray-300">
          <p>&copy; 2025 WhereToVacation. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}

