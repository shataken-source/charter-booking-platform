import { useState } from 'react';
import { Search, User, MessageCircle, GitCompare, Globe, Users, Award, Plane, Calendar, MessagesSquare } from 'lucide-react';

import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';
import { LanguageSwitcher } from '@/components/LanguageSwitcher';
import { useI18n } from '@/contexts/I18nContext';


import Footer from '@/components/Footer';
import MobileMenu from '@/components/MobileMenu';
import DestinationCrawler from '@/components/DestinationCrawler';
import MessageBoard from '@/components/MessageBoard';
import UserAuth from '@/components/UserAuth';
import UserProfile from '@/components/UserProfile';
import AdminPanel from '@/components/AdminPanel';
import ActivitySearch from '@/components/ActivitySearch';
import AdSpots from '@/components/AdSpots';
import YourAdHereBanner from '@/components/YourAdHereBanner';
import AdvancedFilters from '@/components/AdvancedFilters';
import MapView from '@/components/MapView';
import TripPlanner from '@/components/TripPlanner';
import SeasonalDeals from '@/components/SeasonalDeals';
import LocalGuides from '@/components/LocalGuides';
import TravelBlog from '@/components/TravelBlog';
import PremiumMembership from '@/components/PremiumMembership';
import AIRecommendations from '@/components/AIRecommendations';
import RealtimeMessenger from '@/components/RealtimeMessenger';
import { useUser } from '@/contexts/UserContext';
import { destinations as mockDestinations } from '@/data/mockDestinations';





export default function AppLayout() {
  const navigate = useNavigate();
  const { user, isAuthenticated } = useUser();
  const { t } = useI18n();


  const [searchQuery, setSearchQuery] = useState('');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [showCrawler, setShowCrawler] = useState(false);
  const [showMessageBoard, setShowMessageBoard] = useState(false);
  const [showMessenger, setShowMessenger] = useState(false);
  const [showAuth, setShowAuth] = useState(false);
  const [showProfile, setShowProfile] = useState(false);
  const [showComparison, setShowComparison] = useState(false);
  const [showAdminPanel, setShowAdminPanel] = useState(false);
  const [compareList, setCompareList] = useState<any[]>([]);
  const [selectedActivities, setSelectedActivities] = useState<string[]>([]);
  const [selectedDestination, setSelectedDestination] = useState<any>(null);
  const [filters, setFilters] = useState({
    priceRange: [0, 10000] as [number, number],
    guests: 1,
    location: '',
    type: 'all'
  });


  // Filter destinations based on selected activities
  const filteredDestinations = selectedActivities.length > 0
    ? mockDestinations.filter(dest => 
        selectedActivities.some(activity => dest.activities.includes(activity))
      )
    : mockDestinations;


  const handleSearch = (activities: string[], searchTerm: string = '') => {
    setSelectedActivities(activities);
    console.log('Searching for activities:', activities, 'with term:', searchTerm);
  };


  const handleAddToCompare = (id: string) => {
    setCompareList(prev => prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]);
  };

  const handleRemoveFromCompare = (id: string) => {
    setCompareList(prev => prev.filter(i => i !== id));
  };

  const handleBooking = () => {
    alert('Booking functionality - integrate with your booking system!');
  };

  const handleActivityClick = (activity: string) => {
    // Close the modal first
    setSelectedDestination(null);
    // Filter by the clicked activity
    handleSearch([activity]);
    // Scroll to destinations section after a brief delay to allow modal to close
    setTimeout(() => {
      const element = document.getElementById('destinations');
      if (element) {
        element.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    }, 100);
  };




  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navigation */}
      <nav className="bg-gradient-to-r from-blue-600 to-purple-600 text-white shadow-lg sticky top-0 z-30">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <img 
                src="https://d64gsuwffb70l.cloudfront.net/6918960e54362d714f32b6fc_1763250968269_90e31cef.webp" 
                alt="Where to Vacation Logo" 
                className="w-10 h-10 object-contain"
              />
              <a href="#" className="text-2xl font-bold">WhereToVacation.com</a>
            </div>
            <div className="hidden md:flex space-x-4 items-center">
              <a href="#" className="hover:text-gray-200 transition">{t('nav.home')}</a>
              <a href="#destinations" className="hover:text-gray-200 transition">{t('nav.destinations')}</a>
              <a href="#community" className="hover:text-gray-200 transition" onClick={(e) => {
                e.preventDefault();
                setShowMessageBoard(!showMessageBoard);
              }}>
                <MessageCircle className="w-4 h-4 inline mr-1" />
                Community
              </a>
              <Button 
                variant="ghost" 
                className="text-white hover:text-gray-200 hover:bg-white/10"
                onClick={() => setShowCrawler(!showCrawler)}
              >
                <Search className="w-4 h-4 mr-2" />
                AI Crawler
              </Button>
              {compareList.length > 0 && (
                <Button
                  variant="ghost"
                  className="text-white hover:bg-white/10"
                  onClick={() => setShowComparison(true)}
                >
                  <GitCompare className="w-4 h-4 mr-2" />
                  Compare ({compareList.length})
                </Button>
              )}
              {isAuthenticated ? (
                <>
                  <Button
                    variant="ghost"
                    className="text-white hover:bg-white/10"
                    onClick={() => navigate('/my-bookings')}
                  >
                    <Calendar className="w-4 h-4 mr-2" />
                    {t('dashboard.bookings')}
                  </Button>
                  <Button
                    variant="ghost"
                    className="text-white hover:bg-white/10"
                    onClick={() => setShowProfile(true)}
                  >
                    <User className="w-4 h-4 mr-2" />
                    {user?.name}
                  </Button>
                </>

              ) : (
                <Button
                  variant="ghost"
                  className="text-white hover:bg-white/10"
                  onClick={() => setShowAuth(true)}
                >
                  <User className="w-4 h-4 mr-2" />
                  Login
                </Button>
              )}
              <a href="#contact" className="hover:text-gray-200 transition">{t('nav.contact')}</a>
              <LanguageSwitcher />
            </div>
            <button onClick={() => setMobileMenuOpen(true)} className="md:hidden text-2xl">☰</button>
          </div>
        </div>
      </nav>



      <MobileMenu 
        isOpen={mobileMenuOpen} 
        onClose={() => setMobileMenuOpen(false)}
        onShowCrawler={() => setShowCrawler(!showCrawler)}
        onShowMessageBoard={() => setShowMessageBoard(!showMessageBoard)}
        onShowAuth={() => setShowAuth(true)}
        onShowProfile={() => setShowProfile(true)}
        onShowComparison={() => setShowComparison(true)}
        isAuthenticated={isAuthenticated}
        userName={user?.name}
        compareCount={compareList.length}
      />


      {/* Hero Section */}
      <section className="relative h-[500px] flex items-center justify-center text-white">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-900/80 to-purple-900/80 z-10"></div>
        <img
          src="https://d64gsuwffb70l.cloudfront.net/6918960e54362d714f32b6fc_1763244650552_b95d3866.webp"
          alt="Travel Hero"
          className="absolute inset-0 w-full h-full object-cover"
        />
        <div className="relative z-20 text-center px-4 max-w-4xl">
          <h1 className="text-5xl md:text-6xl font-bold mb-6">{t('hero.title')}</h1>
          <p className="text-xl md:text-2xl mb-8">{t('hero.subtitle')}</p>
        </div>

      </section>


      {/* AI Crawler Section */}
      {showCrawler && (
        <section className="container mx-auto px-4 mb-16">
          <DestinationCrawler />
        </section>
      )}

      {/* Activity Search */}
      <section className="container mx-auto px-4 mb-16">
        <ActivitySearch onSearch={handleSearch} />
      </section>

      {/* Ad Banner - Your Ad Here */}
      <section className="container mx-auto px-4 mb-16">
        <YourAdHereBanner format="horizontal" />
      </section>


      {/* Stats Section */}
      <section className="bg-white py-12 mb-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            <div>
              <Globe className="w-12 h-12 mx-auto mb-3 text-blue-600" />
              <div className="text-3xl font-bold text-gray-900">150+</div>
              <div className="text-gray-600">Destinations</div>
            </div>
            <div>
              <Users className="w-12 h-12 mx-auto mb-3 text-purple-600" />
              <div className="text-3xl font-bold text-gray-900">50K+</div>
              <div className="text-gray-600">Happy Travelers</div>
            </div>
            <div>
              <Award className="w-12 h-12 mx-auto mb-3 text-green-600" />
              <div className="text-3xl font-bold text-gray-900">4.8</div>
              <div className="text-gray-600">Average Rating</div>
            </div>
            <div>
              <Plane className="w-12 h-12 mx-auto mb-3 text-orange-600" />
              <div className="text-3xl font-bold text-gray-900">100+</div>
              <div className="text-gray-600">Activities</div>
            </div>
          </div>
        </div>
      </section>

      {/* Destinations Grid */}
      <section id="destinations" className="container mx-auto px-4 mb-16">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold mb-4">
            {selectedActivities.length > 0 ? 'Matching Destinations' : 'Popular Destinations'}
          </h2>
          <p className="text-gray-600 text-lg">
            {selectedActivities.length > 0
              ? `Found ${filteredDestinations.length} destinations for your activities`
              : 'Discover amazing places around the world'}
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredDestinations.map(destination => (
            <div key={destination.id} className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-xl transition cursor-pointer"
              onClick={() => setSelectedDestination(destination)}>
              <img src={destination.image} alt={destination.name} className="w-full h-48 object-cover" />
              <div className="p-4">
                <h3 className="text-xl font-bold mb-2">{destination.name}</h3>
                <p className="text-gray-600 text-sm mb-3">{destination.country}</p>
                <div className="flex flex-wrap gap-2 mb-3">
                  {destination.activities.slice(0, 3).map(activity => (
                    <span key={activity} className="bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded">{activity}</span>
                  ))}
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-lg font-bold text-blue-600">${destination.avgCost}</span>
                  <span className="text-yellow-500">★ {destination.rating}</span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {filteredDestinations.length === 0 && (
          <div className="text-center py-12">
            <p className="text-xl text-gray-600">No destinations found. Try selecting different activities!</p>
          </div>
        )}
      </section>

      {/* Seasonal Deals Section */}
      <SeasonalDeals />

      {/* AI Recommendations Section */}
      <section className="container mx-auto px-4 mb-16">
        <AIRecommendations 
          preferences={selectedActivities} 
          budget={filters.priceRange[1]} 
          travelerType="explorer" 
        />
      </section>

      {/* Local Guides Section */}
      <LocalGuides />

      {/* Travel Blog Section */}
      <TravelBlog />

      {/* Premium Membership Section */}
      <PremiumMembership />

      {/* Real-time Messenger Section */}
      <section className="container mx-auto px-4 mb-16">
        <div className="text-center mb-8">
          <h2 className="text-4xl font-bold mb-4">Travel Community Chat</h2>
          <p className="text-gray-600 text-lg">Connect with fellow travelers in real-time</p>
        </div>
        <RealtimeMessenger />
      </section>

      {/* Message Board Section */}
      {showMessageBoard && (
        <section id="community" className="mb-16">
          <MessageBoard />
        </section>
      )}


      {/* Advertising Section */}
      <section id="advertise" className="mb-16">
        <AdSpots />
      </section>


      {/* Auth Modal */}
      {showAuth && <UserAuth onClose={() => setShowAuth(false)} />}
      
      {/* Profile Modal */}
      {showProfile && <UserProfile onClose={() => setShowProfile(false)} />}


      <Footer />
      {user?.level === 1 && showAdminPanel && <AdminPanel />}

      <Footer />
    </div>
  );
}
