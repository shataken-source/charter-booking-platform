import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { supabase } from '@/lib/supabase';
import { useUser } from '@/contexts/UserContext';
import { Shield, Users, Database, Phone, Download, Upload } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';


export default function AdminPanel() {
  const { user } = useUser();
  const { toast } = useToast();
  const [users, setUsers] = useState<Array<{ email: string; level: number }>>([]);
  const [newEmail, setNewEmail] = useState('');
  const [newLevel, setNewLevel] = useState(10);
  const [loading, setLoading] = useState(false);
  
  // Backup states
  const [backupPhone, setBackupPhone] = useState('');
  const [backupSchedule, setBackupSchedule] = useState('manual');
  const [backupLoading, setBackupLoading] = useState(false);
  const [backups, setBackups] = useState<any[]>([]);
  const [restoreLoading, setRestoreLoading] = useState(false);


  useEffect(() => {
    if (user?.level === 1) {
      loadUsers();
      loadBackups();
    }
  }, [user]);


  const loadUsers = async () => {
    try {
      const { data } = await supabase.functions.invoke('user-level-manager', {
        body: { action: 'list', requestorEmail: user?.email }
      });
      if (data?.users) setUsers(data.users);
    } catch (error) {
      console.error('Failed to load users:', error);
    }
  };

  const updateLevel = async (email: string, level: number) => {
    setLoading(true);
    try {
      await supabase.functions.invoke('user-level-manager', {
        body: { action: 'set', email, level, requestorEmail: user?.email }
      });
      await loadUsers();
    } catch (error) {
      console.error('Failed to update level:', error);
    }
    setLoading(false);
  };

  const loadBackups = async () => {
    try {
      const { data } = await supabase.functions.invoke('database-backup', {
        body: { action: 'list' }
      });
      if (data?.backups) setBackups(data.backups);
    } catch (error) {
      console.error('Failed to load backups:', error);
    }
  };

  const triggerBackup = async () => {
    if (!backupPhone) {
      toast({ title: 'Phone number required', description: 'Please enter a phone number for notifications', variant: 'destructive' });
      return;
    }
    
    setBackupLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('database-backup', {
        body: { action: 'backup', phone: backupPhone, schedule: backupSchedule }
      });
      
      if (error) throw error;
      
      toast({ title: 'Backup completed', description: `${data.recordCount} records backed up successfully` });
      loadBackups();
    } catch (error) {
      console.error('Backup failed:', error);
      toast({ title: 'Backup failed', description: 'Failed to complete backup', variant: 'destructive' });
    }
    setBackupLoading(false);
  };

  const downloadBackup = async (fileName: string) => {
    try {
      const { data } = await supabase.storage.from('database-backups').download(fileName);
      if (data) {
        const url = URL.createObjectURL(data);
        const a = document.createElement('a');
        a.href = url;
        a.download = fileName;
        a.click();
        URL.revokeObjectURL(url);
        toast({ title: 'Download started', description: 'Backup file is downloading' });
      }
    } catch (error) {
      toast({ title: 'Download failed', description: 'Failed to download backup', variant: 'destructive' });
    }
  };

  const restoreBackup = async (fileName: string) => {
    if (!confirm('Are you sure you want to restore this backup? This will overwrite current data.')) return;
    
    setRestoreLoading(true);
    try {
      const { data: fileData } = await supabase.storage.from('database-backups').download(fileName);
      if (fileData) {
        const text = await fileData.text();
        const backupData = JSON.parse(text);
        
        const { data, error } = await supabase.functions.invoke('database-backup', {
          body: { action: 'restore', backupData }
        });
        
        if (error) throw error;
        
        toast({ title: 'Restore completed', description: `${data.restoredCount} records restored` });
      }
    } catch (error) {
      toast({ title: 'Restore failed', description: 'Failed to restore backup', variant: 'destructive' });
    }
    setRestoreLoading(false);
  };



  if (user?.level !== 1) return null;

  return (
    <Card className="max-w-4xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Shield className="w-5 h-5" />
          Admin Panel - User Level Management
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-4">
          <h3 className="font-semibold flex items-center gap-2">
            <Users className="w-4 h-4" />
            Current Users
          </h3>
          <div className="space-y-2">
            {users.map((u) => (
              <div key={u.email} className="flex items-center justify-between p-3 bg-gray-50 rounded">
                <span className="font-medium">{u.email}</span>
                <div className="flex items-center gap-2">
                  <span className="text-sm text-gray-600">Level: {u.level}</span>
                  <Input
                    type="number"
                    min="1"
                    max="10"
                    value={u.level}
                    onChange={(e) => updateLevel(u.email, parseInt(e.target.value))}
                    className="w-20"
                    disabled={loading}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="space-y-4 pt-4 border-t">
          <h3 className="font-semibold">Add/Update User Level</h3>
          <div className="grid gap-4">
            <div>
              <Label>Email</Label>
              <Input
                value={newEmail}
                onChange={(e) => setNewEmail(e.target.value)}
                placeholder="user@example.com"
              />
            </div>
            <div>
              <Label>Level (1-10)</Label>
              <Input
                type="number"
                min="1"
                max="10"
                value={newLevel}
                onChange={(e) => setNewLevel(parseInt(e.target.value))}
              />
            </div>
            <Button onClick={() => updateLevel(newEmail, newLevel)} disabled={loading}>
              Set Level
            </Button>
          </div>
        </div>

        <div className="space-y-4 pt-4 border-t">
          <h3 className="font-semibold flex items-center gap-2">
            <Database className="w-4 h-4" />
            Database Backup
          </h3>
          <div className="grid gap-4">
            <div>
              <Label className="flex items-center gap-2">
                <Phone className="w-4 h-4" />
                SMS Notification Number
              </Label>
              <Input
                type="tel"
                value={backupPhone}
                onChange={(e) => setBackupPhone(e.target.value)}
                placeholder="+1234567890"
              />
            </div>
            <div>
              <Label>Backup Schedule</Label>
              <Select value={backupSchedule} onValueChange={setBackupSchedule}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="manual">Manual Only</SelectItem>
                  <SelectItem value="daily">Daily at 2 AM</SelectItem>
                  <SelectItem value="weekly">Weekly (Sunday 2 AM)</SelectItem>
                  <SelectItem value="monthly">Monthly (1st at 2 AM)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <Button onClick={triggerBackup} disabled={backupLoading}>
              {backupLoading ? 'Processing...' : 'Trigger Backup Now'}
            </Button>

            
            <div className="mt-4">
              <h4 className="font-medium mb-2">Available Backups</h4>
              <div className="space-y-2">
                {backups.length === 0 ? (
                  <p className="text-sm text-gray-500">No backups available</p>
                ) : (
                  backups.map((backup) => (
                    <div key={backup.name} className="flex items-center justify-between p-3 bg-gray-50 rounded">
                      <div>
                        <p className="font-medium text-sm">{backup.name}</p>
                        <p className="text-xs text-gray-500">{new Date(backup.created_at).toLocaleString()}</p>
                      </div>
                      <div className="flex gap-2">
                        <Button size="sm" variant="outline" onClick={() => downloadBackup(backup.name)}>
                          <Download className="w-4 h-4" />
                        </Button>
                        <Button size="sm" variant="outline" onClick={() => restoreBackup(backup.name)} disabled={restoreLoading}>
                          <Upload className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        </div>


      </CardContent>
    </Card>
  );
}
