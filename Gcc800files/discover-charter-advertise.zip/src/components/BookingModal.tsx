import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Checkbox } from './ui/checkbox';
import { supabase } from '@/lib/supabase';

interface BookingModalProps {
  isOpen: boolean;
  onClose: () => void;
  charter: any;
}

export default function BookingModal({ isOpen, onClose, charter }: BookingModalProps) {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    date: '',
    duration: 'Half Day',
    requests: '',
    emailReminder: true,
    smsReminder: false,
    referralCode: ''
  });
  const [loading, setLoading] = useState(false);
  const [creditApplied, setCreditApplied] = useState(0);

  const price = formData.duration === 'Half Day' ? charter.priceHalfDay : charter.priceFullDay;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      // Store booking details for success page
      sessionStorage.setItem('pendingBooking', JSON.stringify({
        charterName: charter.businessName,
        boatType: charter.boatType,
        date: formData.date,
        time: '9:00 AM', // Default time, can be made dynamic
        location: charter.location,
        duration: formData.duration,
        price
      }));

      // Create Stripe checkout session
      const { data, error } = await supabase.functions.invoke('stripe-checkout', {
        body: {
          charterId: charter.id,
          charterName: charter.businessName,
          customerName: formData.name,
          customerEmail: formData.email,
          customerPhone: formData.phone,
          bookingDate: formData.date,
          duration: formData.duration,
          price,
          emailReminder: formData.emailReminder,
          smsReminder: formData.smsReminder,
          captainName: charter.captainName,
          captainPhone: charter.phone,
          captainEmail: charter.email,
          location: charter.location,
          successUrl: `${window.location.origin}/payment-success`,
          cancelUrl: window.location.href
        }
      });

      if (error) throw error;

      // Redirect to Stripe checkout
      if (data.url) {
        window.location.href = data.url;
      }

    } catch (error) {
      console.error('Booking error:', error);
      alert('Failed to create booking. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Book {charter.businessName}</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="name">Full Name</Label>
            <Input
              id="name"
              required
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            />
          </div>

          <div>
            <Label htmlFor="email">Email</Label>
            <Input
              id="email"
              type="email"
              required
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
            />
          </div>

          <div>
            <Label htmlFor="phone">Phone</Label>
            <Input
              id="phone"
              type="tel"
              value={formData.phone}
              onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
            />
          </div>

          <div>
            <Label htmlFor="date">Booking Date</Label>
            <Input
              id="date"
              type="date"
              required
              min={new Date().toISOString().split('T')[0]}
              value={formData.date}
              onChange={(e) => setFormData({ ...formData, date: e.target.value })}
            />
          </div>

          <div>
            <Label htmlFor="duration">Duration</Label>
            <select
              id="duration"
              className="w-full p-2 border rounded"
              value={formData.duration}
              onChange={(e) => setFormData({ ...formData, duration: e.target.value })}
            >
              <option value="Half Day">Half Day (4 hours) - ${charter.priceHalfDay}</option>
              <option value="Full Day">Full Day (8 hours) - ${charter.priceFullDay}</option>
            </select>
          </div>

          <div>
            <Label htmlFor="requests">Special Requests</Label>
            <textarea
              id="requests"
              className="w-full p-2 border rounded"
              rows={3}
              value={formData.requests}
              onChange={(e) => setFormData({ ...formData, requests: e.target.value })}
            />
          </div>

          <div>
            <Label htmlFor="referralCode">Referral Code (Optional)</Label>
            <Input
              id="referralCode"
              placeholder="Enter referral code"
              value={formData.referralCode}
              onChange={(e) => setFormData({ ...formData, referralCode: e.target.value })}
            />
            <p className="text-xs text-gray-500 mt-1">Have a referral code? Enter it to earn credits!</p>
          </div>

          <div className="space-y-3 border-t pt-4">
            <Label className="text-base font-semibold">Reminder Preferences</Label>
            <div className="flex items-center space-x-2">
              <Checkbox
                id="emailReminder"
                checked={formData.emailReminder}
                onCheckedChange={(checked) => 
                  setFormData({ ...formData, emailReminder: checked as boolean })
                }
              />
              <label htmlFor="emailReminder" className="text-sm cursor-pointer">
                Send email reminder 24 hours before charter
              </label>
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox
                id="smsReminder"
                checked={formData.smsReminder}
                onCheckedChange={(checked) => 
                  setFormData({ ...formData, smsReminder: checked as boolean })
                }
              />
              <label htmlFor="smsReminder" className="text-sm cursor-pointer">
                Send SMS reminder (includes weather forecast)
              </label>
            </div>
            <p className="text-xs text-gray-500">
              Reminders include weather forecast, captain contact info, and what to bring checklist
            </p>
          </div>


          <div className="bg-blue-50 p-4 rounded">
            <div className="flex justify-between items-center">
              <span className="font-semibold">Total:</span>
              <span className="text-2xl font-bold text-blue-900">${price}</span>
            </div>
          </div>

          <Button type="submit" className="w-full bg-blue-900 hover:bg-blue-800" disabled={loading}>
            {loading ? 'Processing...' : 'Proceed to Payment'}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}
