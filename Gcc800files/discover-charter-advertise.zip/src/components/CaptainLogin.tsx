import { useState } from 'react';
import { supabase } from '@/lib/supabase';

interface CaptainLoginProps {
  onLoginSuccess: (email: string) => void;
}

export default function CaptainLogin({ onLoginSuccess }: CaptainLoginProps) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    // Demo mode bypass for testing
    if (password === 'demo' || password === 'test') {
      setTimeout(() => {
        onLoginSuccess(email);
        setLoading(false);
      }, 500);
      return;
    }

    try {
      const { data, error } = await supabase.functions.invoke('captain-auth', {
        body: { action: 'login', email, password }
      });

      if (error) throw error;

      if (data.success) {
        onLoginSuccess(email);
      } else {
        setError('Login failed');
      }
    } catch (err: any) {
      setError(err.message || 'Login failed. Try password "demo" for testing.');
    } finally {
      setLoading(false);
    }
  };


  return (
    <div className="max-w-md mx-auto bg-white rounded-lg shadow-lg p-8">
      <h2 className="text-2xl font-bold mb-6">Captain Login</h2>
      <div className="mb-4 bg-blue-50 border border-blue-200 rounded-lg p-3 text-sm">
        <p className="font-semibold text-blue-900 mb-1">Demo Mode Available</p>
        <p className="text-gray-700">Use password "demo" to test without authentication</p>
      </div>
      <form onSubmit={handleLogin}>
        <div className="mb-4">
          <label className="block text-sm font-semibold mb-2">Email</label>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
            className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
            placeholder="mike@gulfstarcharters.com"
          />
        </div>
        <div className="mb-4">
          <label className="block text-sm font-semibold mb-2">Password</label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
            className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
            placeholder="Enter 'demo' for testing"
          />
        </div>
        {error && <div className="mb-4 text-red-600 text-sm">{error}</div>}
        <button
          type="submit"
          disabled={loading}
          className="w-full bg-blue-900 hover:bg-blue-800 text-white py-3 rounded-lg font-semibold transition disabled:opacity-50"
        >
          {loading ? 'Logging in...' : 'Login'}
        </button>
      </form>
    </div>
  );
}

