interface ReminderEmailProps {
  customerName: string;
  charterName: string;
  date: string;
  time: string;
  location: string;
  duration: string;
  captainName: string;
  captainPhone: string;
  captainEmail: string;
  weather: {
    temp: number;
    description: string;
    windSpeed: number;
    humidity: number;
  };
}

export const ReminderEmailTemplate = ({
  customerName,
  charterName,
  date,
  time,
  location,
  duration,
  captainName,
  captainPhone,
  captainEmail,
  weather
}: ReminderEmailProps) => {
  const checklist = [
    'Valid ID or passport',
    'Sunscreen (reef-safe recommended)',
    'Sunglasses and hat',
    'Light jacket or windbreaker',
    'Camera or phone for photos',
    'Seasickness medication (if needed)',
    'Snacks and drinks (if not provided)',
    'Towel and swimwear',
    'Cash for tips'
  ];

  return (
    <div className="max-w-2xl mx-auto p-6 bg-white">
      <h2 className="text-2xl font-bold text-blue-600 mb-4">Your Charter Reminder - Tomorrow!</h2>
      <p className="mb-4">Hi {customerName},</p>
      <p className="mb-6">This is a friendly reminder that your charter is scheduled for <strong>tomorrow, {date}</strong>.</p>
      
      <div className="mb-6">
        <h3 className="text-xl font-semibold mb-3">Charter Details</h3>
        <ul className="space-y-2">
          <li><strong>Charter:</strong> {charterName}</li>
          <li><strong>Date:</strong> {date} at {time}</li>
          <li><strong>Location:</strong> {location}</li>
          <li><strong>Duration:</strong> {duration}</li>
        </ul>
      </div>

      <div className="mb-6 bg-blue-50 p-4 rounded-lg">
        <h3 className="text-xl font-semibold mb-3">Weather Forecast</h3>
        <p><strong>Temperature:</strong> {weather.temp}°F</p>
        <p><strong>Conditions:</strong> {weather.description}</p>
        <p><strong>Wind Speed:</strong> {weather.windSpeed} mph</p>
        <p><strong>Humidity:</strong> {weather.humidity}%</p>
      </div>

      <div className="mb-6">
        <h3 className="text-xl font-semibold mb-3">Captain Contact</h3>
        <p><strong>Captain:</strong> {captainName}</p>
        <p><strong>Phone:</strong> {captainPhone}</p>
        <p><strong>Email:</strong> {captainEmail}</p>
      </div>

      <div className="mb-6">
        <h3 className="text-xl font-semibold mb-3">What to Bring</h3>
        <ul className="list-disc pl-6 space-y-1">
          {checklist.map((item, index) => (
            <li key={index}>{item}</li>
          ))}
        </ul>
      </div>

      <p className="mb-2">If you need to make any changes or have questions, please contact your captain directly.</p>
      <p className="mb-4">Have a wonderful charter experience!</p>
      <p className="font-bold">Gulf Coast Charter</p>
    </div>
  );
};