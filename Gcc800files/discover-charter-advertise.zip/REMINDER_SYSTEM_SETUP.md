# Automated Reminder System Setup

## Overview
The booking reminder system automatically sends emails and SMS messages 24 hours before charter bookings, including:
- Weather forecast for the booking date
- Captain contact information
- What to bring checklist

## Components Created

### 1. Edge Functions
- **booking-reminder-scheduler**: Sends reminder emails/SMS with weather and captain info
- **stripe-checkout**: Updated to store reminder preferences in Stripe metadata

### 2. Frontend Components
- **BookingModal**: Updated with reminder preference checkboxes
- **ReminderEmailTemplate**: Email template component for reminders

## How It Works

1. Customer books a charter and opts in for reminders (email/SMS)
2. Reminder preferences stored in Stripe checkout metadata
3. 24 hours before booking, the reminder scheduler is triggered
4. System fetches weather forecast from OpenWeatherMap API
5. Email/SMS sent via Brevo with all booking details

## Manual Trigger

To manually send a reminder for a booking:

```javascript
const { data } = await supabase.functions.invoke('booking-reminder-scheduler', {
  body: {
    booking: {
      customerName: 'John Doe',
      customerEmail: 'john@example.com',
      customerPhone: '+1234567890',
      charterName: 'Deep Sea Fishing',
      date: '2024-12-25',
      time: '9:00 AM',
      location: 'Gulf Shores, AL',
      duration: 'Full Day',
      captainName: 'Captain Mike',
      captainPhone: '+1987654321',
      captainEmail: 'mike@charter.com'
    },
    sendSms: true
  }
});
```

## Automated Scheduling (Recommended)

Set up a cron job using a service like:
- **Supabase Cron Jobs** (pg_cron extension)
- **GitHub Actions** (scheduled workflows)
- **Vercel Cron Jobs**
- **External cron service** (cron-job.org)

The cron job should:
1. Query Stripe for bookings with date = tomorrow
2. Filter for bookings with reminder preferences
3. Call booking-reminder-scheduler for each booking

## Environment Variables Required
- `BREVO_API_KEY`: For sending emails and SMS
- `OPENWEATHERMAP_API_KEY`: For weather forecasts
- `STRIPE_SECRET_KEY`: For querying booking metadata

All variables are already configured in your Supabase project.
